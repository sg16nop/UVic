/* File: csvfunctions.c

   ==> THIS IS THE FILE YOU CHANGE <==

   IMPORTANT:  Replace the line above with your student number and your name.
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "csvfunctions.h"

#define MAXINPUTLINELEN     256

static SPREADSHEET theSS;   // the spreadsheet to work on
static int debug = 0;
static int tooWide = 0;


// forward declaration
static int extractItems(char *line, char row[][MAXLEN]);

void SS_SetDebug(int dbg) {
    debug = dbg;
}

SPREADSHEET *SS_ReadCSV(char *fileName) {
    char line[MAXINPUTLINELEN];
    SPREADSHEET result;
    int i;

    result.fileName = fileName;
    result.numRows = result.numCols = 0;

    FILE *f = fopen(fileName, "r");
    if (f == NULL) {
        fprintf(stderr, "Unable to read from file %s\n", fileName);
        perror(fileName);
        return NULL;
    }
    for( i = 0; i < MAXROWS; i++) {
        if (fgets(line, MAXINPUTLINELEN, f) == NULL) {
            // i--;    <=== this was a mistake!!
            break;
        }
        int k = extractItems(line, result.contents[i]);
        if (result.numCols == 0) {
            result.numCols = k;
        } else
        if (result.numCols != k) {
            fprintf(stderr, "Row %d has different number of columns from first row\n", i);
        }
    }
    result.numRows = i;
    fclose(f);
    memcpy(&theSS, &result, sizeof(SPREADSHEET));
    if (tooWide)
        fprintf(stderr, "Warning, number of columns exceeded the max of %d\n", MAXCOLS);
    return &theSS;
}

static char *getOneItem(char *line, char *tok) {
    char *tokSaved = tok;
    char c;
    c = *line++;
S1: if (c == '\"') {
        c = *line++;
        goto S2;
    }
    if (c == ',' || c == '\0' || c == '\n' || c == '\r') {
        goto S4;
    }
    *tok++ = c;
    c = *line++;
    goto S1;
S2: if (c == '\"') {
        c = *line++;
        goto S3;
    }
    if (c == '\0' || c == '\n' || c == '\r') {
        // unexpected end of input line
        fprintf(stderr, "mismatched doublequote found");
        goto S4;
    }
    *tok++ = c;
    c = *line++;
    goto S2;
S3: if (c == '\"') {
        *tok++ = '\"';
        c = *line++;
        goto S2;
    }
    if (c == ',' || c == '\0' || c == '\n' || c == '\r') {
        goto S4;
    }
    *tok++ = c;
    c = *line++;
    goto S1;
S4: if (c == '\0' || c == '\n' || c == '\r') {
        if (tokSaved == tok)
            return NULL;  // nothing was read
        line--;
    }
    *tok = '\0';
    return line;
}

static int extractItems(char *line, char row[][MAXLEN]) {
    char t[MAXINPUTLINELEN];
    int col = 0;
    for( ; ; ) {
        line = getOneItem(line,t);
        if (line == NULL) break;
        strncpy(row[col++], t, MAXLEN);
    }
    return col;
}

// Searches down the specified column for a row which contains text.
// The search starts at row number startNum;
// The result is the row number (where the first row is numbered 0).
// If the text is not found, the result is -1.
int SS_FindRow(SPREADSHEET *ss, int colNum, char *text, int startNum) {
    if (debug)
        fprintf(stderr, "DEBUG: Call to SS_FindRow(--,%d,%s,%d)\n",
            colNum, text, startNum);
    int i;
    for( i=startNum; i < ss->numRows; i++ ) {
        if (strcmp(ss->contents[i][colNum],text) == 0)
            return i;
    }
    return -1;
}

// Outputs the specified row of the spreadsheet.
// It is printed as one line on standard output.
void SS_PrintRow(SPREADSHEET *ss, int rowNum) {
    if (debug)
        fprintf(stderr, "DEBUG: Call to SS_PrintRow(--,%d)\n", rowNum);
    if (rowNum >= ss->numRows || rowNum < 0) {
        printf("Row number (%d) is out of range\n", rowNum);
        return;
    }
    int j;
    for( j=0; j < ss->numCols; j++ ) {
        if (j > 0)
            putchar(',');
        printf("%s", ss->contents[rowNum][j]);
    }
    putchar('\n');
    return;
}

// The specified column must contain the textual representations of numbers
// (either integer or floating point). The sum of the numbers in the column
// is returned as a floating point number.
double SS_ColumnSum(SPREADSHEET *ss, int colNum) {
    if (debug)
        fprintf(stderr, "DEBUG: Call to SS_ColumnSum(--,%d)\n", colNum);
    // TO BE COMPLETED!
    // Note: atof(s) converts a string s to a float value
    double sum = 0.0;
    int i;
    for( i=0; i < ss->numRows; i++ ) {
        double val = atof(ss->contents[i][colNum]);
        sum += val;
    } 
    return sum;
}

double SS_ColumnAvg(SPREADSHEET *ss, int colNum) {
    if (debug)
        fprintf(stderr, "DEBUG: Call to SS_ColumnAvg(--,%d)\n", colNum);
    double sum = SS_ColumnSum(ss,colNum);
    return sum/ss->numRows;
}

