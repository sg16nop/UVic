#!/usr/bin/python

# This is Python2 code

##  checkAss1.py filename
##
##  The specified file is checked to see whether it is a plausible submission
##  for Assignment 1.
##
##  This script should be executed on a SENG EOW B215 computer to
##  ensure gcc compiler compatibility.

# Checks:
#   1.  Does the file have the right name?
#   2.  Warn if the file has DOS line endings.
#   3.  Does the file contain a student V number in the first 10 lines?
#   4.  Does the file compile and link?
#   5.  Does one simple test case run?

from __future__ import print_function
import os
import os.path
import codecs
import sys
import re
import subprocess
import shutil
import tempfile


tmpdir = None
srcfolder = None
filename = None

gcc = r"/usr/bin/gcc"  ## path on B215 Linux computers and cygwin
submitfilename = "csvfunctions.c"
firstfilename = "ass1.c"
hdrfilename = "csvfunctions.h"
testfilename = "testfile.csv"
onequery = "query.txt"
srcFolderPlaces = [r"/home/nigelh/seng265/ass1", r"/home/Nigel/Seng265-Fall2014/ass1"]
vnumpat = re.compile("\bV00\d\d\d\d\d\d\b")

dosmessage = """Your file appears to have Windows line endings.
This doesn't affect the gcc compiler, but can cause trouble for
some editor programs on Linux. If you do have trouble (such as
seeing ^M characters) use the dos2unix Linux command to convert
the file to use Linux format line endings."""

def findSrcFolder():
    # nonlocal srcfolder  # Python3 feature
    global srcfolder
    if srcfolder != None:
        return  # set on command line
    ## try other places
    for f in srcFolderPlaces:
        if os.path.exists(f):
            srcfolder = f
            return
    print("ass1 source files folder not found")
    sys.exit(1)

def setuptmpfolder():
    # nonlocal tmpdir  # Python3 feature
    global tmpdir
    tmpdir = tempfile.mkdtemp()
    f1 = os.path.join(srcfolder,firstfilename)
    shutil.copy(f1,tmpdir)
    f2 = os.path.join(srcfolder,hdrfilename)
    shutil.copy(f2,tmpdir)
    f3 = os.path.join(srcfolder,testfilename)
    shutil.copy(f3,tmpdir)
    qpath = os.path.join(tmpdir,onequery)
    ff = open(qpath, "w")
    ff.write("printrow 2\nquit\n")
    ff.close()
    
    
def removetmpfolder():
    # nonlocal tmpdir  # Python3 feature
    global tmpdir
    shutil.rmtree(tmpdir)
    tmpdir = None

## run gcc program on one C file
def testsubmission( testcase ):
    ## correct name?
    (dir,basename) = os.path.split(testcase)
    if basename != submitfilename:
        print("\nSupplied file (%s) has the wrong name; it should be %s" % (basename, submitfilename))
        return None
    ## can we read the file?
    try:
        f = open(testcase)
        textlines = f.readlines()
    except:
        print("\nUnable to read file "+testcase)
        return None
    ## is there a student number near file beginning
    vnumfound = False
    dos = False
    n = 0
    for line in textlines:
        n += 1
        if line[-1:] == '\r':
            dos = True
        if n<=10 and not vnumfound:
            if vnumpat.search(line):
                vnumfound = True
    if not vnumfound:
        print("\nNo V00...... student number was found in the first 10 lines of your file.\n")
    if dos:
        print(dosmessage)
    f.close()

    shutil.copy(testcase,tmpdir)

    gccOutput = "gcc-output.txt"
    resultsPath = os.path.join(tmpdir,gccOutput)
    resultFile = open(resultsPath, "w")
    queryPath = os.path.join(tmpdir,onequery)
    testQueryStream = open(queryPath)
    xfile = "ass1.exe"

    ## does it compile?
    os.chdir(tmpdir)
    command1 = [gcc, firstfilename, submitfilename, "-o", xfile]
    print("Compile command is:  " + " ".join(command1))
    p = subprocess.call(command1, stdout=resultFile, stderr=resultFile)
    
    ## did we create an executable file?
    if not os.path.exists(xfile):
        print("\n- no executable file created\n", file=resultFile)
        resultFile.flush()
        return ("C",resultsPath)
    if not os.access(xfile,os.X_OK):
        print("\n- target file exists but is not executable\n", file=resultFile)
        resultFile.flush()
        return ("C",resultsPath)

    ## can we execute the program?
    command2 = [os.path.join(".",xfile), testfilename]
    print("Execute command is:  " + " ".join(command2))
    p = subprocess.call(command2, stdin=testQueryStream, stdout=resultFile, stderr=resultFile)
    resultFile.flush()
    resultFile.close()
    return ("X",resultsPath)

#----------------- main program follows -----------------------

## process command line arguments
i = 1
numArgs = len(sys.argv)
while i < numArgs:
    arg = sys.argv[i]
    i += 1
    if arg == "-s":
        srcfolder = sys.argv[i]
        i += 1
    else:
        if filename == None:
            filename = arg
        else:
            print("Only one file name argument can be provided")
if filename == None:
    filename = submitfilename

## now start the testing procedure
findSrcFolder()
setuptmpfolder()
status = testsubmission(filename)
if status != None:
    (code,path) = status
    results = open(path)
    if code != "X":
        print("\nThese gcc compiler messages were produced:\n")
        for line in results:
            print(line)
        print("\nThey need to be examined and fixed.\n")
    else:
        row = ["Jill","21","115.0","blonde"]
        found = False
        for line in results:
            if line.find("Jill") >= 0:
                found = True
                break
        if not found:
            print("\nThe subcommand 'printrow 2' should have displayed the row containing\n\t%s" % " ".join(row))
            print("Instead, the output was: \n%s\n" % "\n".join(results))
        else:
            print("\nYour program compiles without error, and runs a simple test case. Well done!\n")
    results.close()
        
removetmpfolder()
